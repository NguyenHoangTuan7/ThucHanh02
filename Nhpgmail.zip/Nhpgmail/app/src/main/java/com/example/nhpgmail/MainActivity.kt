// Giữ nguyên package name
package com.example.nhpgmail

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
// SỬA DÒNG NÀY: Dùng đúng tên Theme là "NhậpGmailTheme"
import com.example.nhpgmail.ui.theme.NhậpGmailTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // SỬA Ở ĐÂY: Dùng đúng tên Theme
            NhậpGmailTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    EmailValidatorScreen()
                }
            }
        }
    }
}

@Composable
fun EmailValidatorScreen() {
    var emailInput by remember { mutableStateOf("") }
    var validationMessage by remember { mutableStateOf("") }
    var messageColor by remember { mutableStateOf(Color.Red) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Thực hành 02",
            fontSize = 20.sp,
            style = MaterialTheme.typography.titleMedium
        )

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = emailInput,
            onValueChange = { emailInput = it },
            label = { Text("Email") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = validationMessage,
            color = messageColor,
            fontSize = 14.sp,
            modifier = Modifier
                .fillMaxWidth()
                .height(20.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                if (emailInput.isBlank()) {
                    validationMessage = "Email không hợp lệ"
                    messageColor = Color.Red
                } else if (!emailInput.contains("@")) {
                    validationMessage = "Email không đúng định dạng"
                    messageColor = Color.Red
                } else {
                    validationMessage = "Bạn đã nhập email hợp lệ"
                    messageColor = Color(0xFF00C853)
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            shape = RoundedCornerShape(25.dp)
        ) {
            Text(text = "Kiểm tra", fontSize = 16.sp)
        }
    }
}

@Preview(showBackground = true, name = "Email Validator Preview")
@Composable
fun DefaultPreview() {
    // SỬA Ở ĐÂY: Dùng đúng tên Theme
    NhậpGmailTheme {
        EmailValidatorScreen()
    }
}
